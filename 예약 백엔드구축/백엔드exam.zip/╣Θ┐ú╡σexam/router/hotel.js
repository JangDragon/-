import express from 'express'
import * as hotelController from '../controller/hotel.js'
import {isAuth} from '../middleware/member.js'

const router = express.Router()

// 호텔리스트
// http://localhost:8080/hotel/list
router.get('/list', hotelController.getList);


// 호텔정보확인(로그인해야함)
// http://localhost:8080/hotel/info/:호텔코드
router.get('/info/:code', isAuth, hotelController.getInfo);

// 호텔예약(로그인해야함)
// http://localhost:8080/hotel/reservation/:호텔코드
// 입력예시
// {
//     "username":"banana",
//     "code":"002"
// }
router.post('/reservation/:code/', isAuth, hotelController.postReserve);

// 호텔예약정보확인(로그인해야함)
// http://localhost:8080/hotel/reservation/:호텔코드
router.get('/reservation/:code', isAuth, hotelController.getInfo_reserve);

// 호텔예약취소(로그인해야함)
// http://localhost:8080/hotel/reservation/:호텔코드
router.delete('/reservation/:code', isAuth, hotelController.deleteReserve);


export default router