import express from 'express';
import { body } from 'express-validator';
import * as authController from '../controller/member.js';
import { validate } from '../middleware/validator.js';
import {isAuth} from '../middleware/member.js'

const router = express.Router();

const validateLogin = [
    body('username').trim().notEmpty().withMessage('username 입력'),
    body('password').trim().isLength({min:4}).withMessage('password는 최소 4자 이상 입력'), validate
]

const validateSignup = [
    ... validateLogin,
    body('name').trim().notEmpty().withMessage('name을 입력'),
    body('gender').trim().notEmpty().withMessage('성별 입력'),
    validate
]

// 회원등록
// http://localhost:8080/member/regist
// 입력예시
// {
//     "username": "banana",
//     "password": "abcd1234",
//     "name": "반하나",
//     "gender": "남자"
// }
router.post('/regist', validateSignup, authController.signup);


// 로그인
// http://localhost:8080/member/login
// 입력예시
// {
//     "username":"banana",
//     "password":"abcd1234"
// }
router.post('/login', validateLogin, authController.login);


// 회원정보 수정(이름만 변경)
// http://localhost:8080/member/info
// 입력예시
// {
//     "username":"banana",
//     "name":"반함"
// }
router.put('/info', isAuth, authController.info)
export default router;