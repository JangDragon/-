import Mongoose from 'mongoose'
import { useVirtualId } from '../db/database.js'

// let users = [
//     {
//         id: '자동 생성',
//         username: "apple",
//         password: "$2b$10$V2JFRJugCJzxe6YtQWJ4Iu/MO7/r8E.n5LC8vSbFGsHc6/aqoXyAi", // 'abcd1234'의 해시값
//         name: "김사과",
//         gender: "남자",
//         createdAt: Date.now().toString()
//     }
// ]
const userSchema = new Mongoose.Schema({
    username: {type: String, require: true},
    password: {type: String, require: true},
    name: {type: String, require: true},
    gender: {type: String, require: true},
    createdAt: { type: Date, default: Date.now }
})

useVirtualId(userSchema);

const User = Mongoose.model('User', userSchema);

// 아이디 중복검사
export async function findByUsername(username){
    return User.findOne({username});
}

// id 중복검사
export async function findById(id){
    return User.findById(id);
}

// 회원데이터 저장
export async function createUser(user){
    return new User(user).save().then((data) => data.id)
}

// 회원정보 수정(이름만 수정)
export async function update(id, name) {
    return User.findByIdAndUpdate(id, {name}, {returnDocument: "after"})
}