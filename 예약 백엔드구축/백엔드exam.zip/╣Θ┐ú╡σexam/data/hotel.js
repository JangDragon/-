import Mongoose from 'mongoose'
import { useVirtualId } from '../db/database.js'
import * as authRepository from '../data/member.js';


// 호텔 스키마
const hotelSchema = new Mongoose.Schema({
    code: {type: String, require: true},
    name: {type: String, require: true},
    location: {type: String, require: true},
    hp: {type: String},
    homepage: {type: String}
})
useVirtualId(hotelSchema);
const Hotel = Mongoose.model('Hotel', hotelSchema);
delete Mongoose.connection.models['Hotel'];

// 호실 스키마
const roomSchema = new Mongoose.Schema({
    code: {type: String, require: true},
    date: {type: String, require: true},
    time: {type: String, require: true},
    price: {type: String, require: true},
    description: {type: String, require: true}
})
useVirtualId(roomSchema);
const Room = Mongoose.model('Room', roomSchema);
delete Mongoose.connection.models['Room'];

// 예약 스키마
const reserveSchema = new Mongoose.Schema({
    username: {type: String, require: true},
    name: {type: String, require: true},
    code: {type: String, require: true},
    hotelName: {type: String, require: true},
    createdAt: { type: Date, default: Date.now },
    checkIn : {type: String, default: "21시"},
    checkOut : {type:String, default: "09시"}
})
useVirtualId(reserveSchema);
const Reserve = Mongoose.model('Reserve', reserveSchema);
delete Mongoose.connection.models['Reserve'];


// 모든 호텔리스트 리턴
export async function getAll() {
    return Hotel.find().sort({createdAt: -1});
}

// code에 따른 데이터 반환(hotel)
export async function getByCode(code){
    return Hotel.findOne({ code: code });
}

// code에 따른 데이터 반환(room)
export async function getById(code){
    return Room.findOne({ code: code });
}

// code에 따른 예약정보 추가
export async function createReserve(username, code){
    let temp;
    const hotel = getByCode(code).then((x)=> {
        temp = x.name
        return temp
    })
    return authRepository.findByUsername(username).then((user) => new Reserve({
        username, name:user.name, code, hotelName:temp
    }).save()
)}

// resrve에서 code 중복 확인
export async function existCode(code){
    return Reserve.findOne({ code: code });
}

// 예약 삭제
export async function remove(code){
    return Reserve.findOneAndDelete(code)
}