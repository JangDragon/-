import * as hotelRepository from '../data/hotel.js';

// 호텔리스트를 가져오는 함수
export async function getList(req, res){
    const data = await hotelRepository.getAll();
    res.status(200).json(data);
}

// 각 호텔의 호실정보를 가져오는 함수
export async function getInfo(req, res, next) {
    const code = req.params.code;
    const info = await hotelRepository.getById(code);
    if(info){
        res.status(200).json(info);
    }else{
        res.status(404).json({message:`코드가 ${code}인 호텔이 없습니다.`})
    }
}

// 예약을 생성하는 함수
export async function postReserve(req, res, next) {
    let { username, code } = req.body;
    console.log(req.body)
    const found = await hotelRepository.existCode(code)
    if(found){
        return res.status(409).json({ message: `이미 예약되었습니다.` })
    }
    const reserve = await hotelRepository.createReserve(username, code);
    res.status(201).json(reserve);
}

// 예약 확인하는 함수
export async function getInfo_reserve(req, res, next) {
    const code = req.params.code;
    const reserve = await hotelRepository.existCode(code);
    if(reserve){
        res.status(200).json(reserve);
    }else{
        res.status(404).json({message:`예약되어 있지 않습니다.`})
    }
}

// 예약 삭제하는 함수
export async function deleteReserve(req, res, next) {
    const code = req.params.code;
    await hotelRepository.remove(code);
    res.sendStatus(204);
}